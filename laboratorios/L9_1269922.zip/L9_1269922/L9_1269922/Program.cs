﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_1166322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            circulo1 objcirculo = new circulo1(67);

            double area =objcirculo.Obtenerarea();
            double perimetro = objcirculo.ObtenerPerimetro();
            double volumen = objcirculo.ObteneVolumen();



        }
    }
}
