﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_1269922
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Circulo1 objcirculo = new Circulo1(67);

            double area =objcirculo.Obtenerarea();
            double perimetro = objcirculo.ObtenerPerimetro();
            double volumen = objcirculo.ObtenerVolumen();



        }
    }
}
