﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_1269922
{
    internal class Circulo1
    {
        //atributo
        private double radio;

        //metodo constructor, opcional
        public Circulo1(double radio)
        {
            this.radio = radio;
        }
        public double ObtenerPerimetro()
        {
            return 2 * Math.PI * radio;
        }

        public double Obtenerarea()
        {
            return Math.PI * Math.Pow(radio, 2);
        }

        public double ObtenerVolumen()
        {
            return 4 / 3 * Math.PI * Math.Pow(radio, 3);
        }
        public void CalcularGeometria(double UnPerimetro, double UnArea, double UnVolumen)
        {
            Console.WriteLine("Perimetro: " + UnPerimetro);
            Console.WriteLine("Area: " + UnArea);
            Console.WriteLine("Volumen: " + UnVolumen);

        }
    }
}