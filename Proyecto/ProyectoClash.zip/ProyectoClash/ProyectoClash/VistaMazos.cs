﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoClash
{
    public partial class VistaMazos : Form
    {
        public VistaMazos()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PvP p = new PvP();
            p.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mazos m = new Mazos();
            m.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mazo2 m2 = new Mazo2();
            m2.Show();
        }
    }
}
