﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoClash
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombre, equipo, nick, nc = "", nm = "";
            int largo;
            
            nombre = textBox2.Text;
            equipo = textBox1.Text;
            string[] words = equipo.Split(' ');
            foreach (string word in words)
            {
                nc += word.Substring(0, 1);
            }
            if(nombre.Contains(" "))
            {
                nm = nombre.Replace(" ", "");
            }
            nick = nc + nm;
            largo = nick.Length;
            nick = nc + nm + largo;

            lblNombre.Text = nombre;
            lblEquipo.Text = equipo;
            lblNick.Text = nick;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nombre, equipo, nick, nc = "", nm = "";
            int largo;

            nombre = textBox4.Text;
            equipo = textBox3.Text;
            string[] words = equipo.Split(' ');
            foreach (string word in words)
            {
                nc += word.Substring(0, 1);
            }
            if (nombre.Contains(" "))
            {
                nm = nombre.Replace(" ", "");
            }
            nick = nc + nm;
            largo = nick.Length;
            nick = nc + nm + largo;

            lblNombre2.Text = nombre;
            lblEquipo2.Text = equipo;
            lblNick2.Text = nick;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            VistaMazos v = new VistaMazos();
            v.Show();
        }
    }
}
