﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoClash
{
    public partial class PvP : Form
    {
        public PvP()
        {
            InitializeComponent();
        }
        

        public string var1 = "inicio";
        public string var2 = "inicio";

        private void btnEmpezar_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = true;
            MessageBox.Show("Selecciona un mazo por favor", "Jugador 1");

            groupBox2.Enabled = true;
        }

        private void btnGuerra_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ha seleccionado el mazo " + "'GuerraClan'");
            MessageBox.Show("Selecciona un mazo por favor", "Jugador 2");
            var1 = "guerraclan";
        }

        private void btnClassics_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ha seleccionado el mazo " + "'CLassics'");
            MessageBox.Show("Selecciona un mazo por favor", "Jugador 2");
            var1 = "classics";
        }

        private void btnElite_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ha seleccionado el mazo " + "'EliteGDB'");
            var2 = "elite";
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ha seleccionado el mazo " + "'Log Bait'");
            var2 = "logbait";
        }

        private void btnComparar_Click(object sender, EventArgs e)
        {

            if (var1 == "guerraclan")
            {
                txtDaño1.Text = "2240";
                txtVida1.Text = "8240";
                lblAtaque1.Text = "El ataque de este mazo es" + Environment.NewLine +
                "muy poderoso ya que cuenta con cartas" + Environment.NewLine +
                "fuertes aunque un poco costosas";
                lblBalance1.Text = "El balance de este mazo es" + Environment.NewLine +
                "medio debido a que sus cartas son" + Environment.NewLine +
                "costosas, aunque si tiene ataque y" + Environment.NewLine +
                "una buena defensa";
            }
            else if (var1 == "classics")
            {
                txtDaño1.Text = "2361";
                txtVida1.Text = "7174";
                lblAtaque1.Text = "El ataque de este mazo es decente" + Environment.NewLine +
                "aunque podria ser mejor y sobretodo" + Environment.NewLine +
                "mas eficiente";
                lblBalance1.Text = "El balance de este mazo es" + Environment.NewLine +
                "excelente debido a que tiene cartas" + Environment.NewLine +
                "de coste medio y se puede defender" + Environment.NewLine +
                "bastante bien";
            }

            if (var2 == "elite")
            {
                txtDaño2.Text = "1806";
                txtVida2.Text = "10989";
                lblAtaque2.Text = "El ataque de este mazo puede" + Environment.NewLine +
                "ser poderoso si se arma un buen" + Environment.NewLine +
                "combo con sus cartas y ayuda" + Environment.NewLine +
                "que no sean tan costosas";
                lblBalance2.Text = "El balance de este mazo es medio" + Environment.NewLine +
                "debido a que sus cartas son costosas" + Environment.NewLine +
                "aunque si tiene ataque y una buena" + Environment.NewLine +
                "defensa";
            }
            else if (var2 == "logbait")
            {
                txtDaño2.Text = "3018";
                txtVida2.Text = "5806";
                lblAtaque2.Text = "El ataque de este mazo es rapido" + Environment.NewLine +
                "por lo que se debe jugar con" + Environment.NewLine +
                "estrategia, tambien es muy eficiente";
                lblBalance2.Text = "El balance de este mazo es" + Environment.NewLine +
                "excelente debido a que tiene cartas" + Environment.NewLine +
                "de coste bajo y se puede defender y" + Environment.NewLine +
                "atacar bastante bien";
            }
            int cont1 = 0, cont2 = 0;
            int daño1 = Convert.ToInt16(txtDaño1.Text);
            int vida1 = Convert.ToInt16(txtVida1.Text);
            int daño2 = Convert.ToInt16(txtDaño2.Text);
            int vida2 = Convert.ToInt16(txtVida2.Text);
            if (daño1 > daño2)
            {
                MessageBox.Show("El mazo del jugador 1 es superior en daño", "Alerta");
                cont1++;
                if (vida1 > vida2)
                {
                    MessageBox.Show("El mazo del jugador 1 es superior en vida", "Alerta");
                    cont1++;
                }
                else
                {
                    MessageBox.Show("El mazo del jugador 2 es superior en vida", "Alerta");
                    cont2++;
                }
            }
            else
            {
                MessageBox.Show("El mazo del jugador 2 es superior en daño", "Alerta");
                cont2++;
                if (vida1 > vida2)
                {
                    MessageBox.Show("El mazo del jugador 1 es superior en vida", "Alerta");
                    cont1++;
                }
                else
                {
                    MessageBox.Show("El mazo del jugador 2 es superior en vida", "Alerta");
                    cont2++;
                }
            }
            if (cont1 > cont2)
            {
                MessageBox.Show("El mazo del jugador 1 tiene mas probabilidades de ganar", "Conclusion");
            }
            else
            {
                MessageBox.Show("El mazo del jugador 2 tiene mas probabilidades de ganar", "Conclusion");
            }
        }
    }
}
