﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoClash
{
    public class Deck
    {
        private int _puntosVida;
        private int _daño;
        private int _ataque;
        private int _defensa;
        private int _sinergia;
        private int _balance;
        private string _nombre;


        public Carta[] Cartas { get; set; }

        public int PuntosVida
        {
            get { return _puntosVida; }
            set { _puntosVida = value; }
        }
        public int Daño
        {
            get { return _daño; }
            set { _daño = value; }
        }
        public int Ataque
        {
            get { return _ataque; }
            set { _ataque = value; }
        }
        public int Defensa
        {
            get { return _defensa; }
            set { _defensa = value; }
        }
        public int Sinergia
        {
            get { return _sinergia; }
            set { _sinergia = value; }
        }
        public int Balance
        {
            get { return _balance; }
            set { _balance = value; }
        }
        public string Nombre
        {
            get { return _nombre; }
            set { _nombre = value; }
        }
        public int GetDañoTotal(Carta[] cartas)
        {
            int suma = 0;
            for(int i = 0; i < cartas.Length; i++) {
                suma += cartas[i].Daño;
            }
            return suma;
        }
        public int GetPuntosDeVida(Carta[] cartas)
        {
            int suma = 0;
            for (int i = 0; i < cartas.Length; i++)
            {
                suma += cartas[i].PuntosVida;
            }
            return suma;
        }

        public Deck(string nNombre, Carta[] cartas)
        {
            Nombre = nNombre;
            Cartas = cartas;
        }
    }
}
