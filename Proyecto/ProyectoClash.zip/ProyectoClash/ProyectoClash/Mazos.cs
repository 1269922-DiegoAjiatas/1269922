﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoClash
{
    public partial class Mazos : Form
    {
        public Mazos()
        {
            InitializeComponent();

            
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            //Creando las cartas que se utilizaran
            Carta megacaballero = new Carta("Megacaballero", 3993, 268);
            Carta tronco = new Carta("Tronco", 0, 290);
            Carta espejo = new Carta("Espejo", 0, 0);
            Carta magohielo = new Carta("Mago de Hielo", 688, 90);
            Carta guardias = new Carta("Guardias", 81, 121);
            Carta pandilla = new Carta("Pandilla de duendes", 133, 81);
            Carta lanzafuegos = new Carta("Lanzafuegos", 304, 320);
            Carta esqueletos = new Carta("Esqueletos", 81, 81);
            Carta globo = new Carta("Globo Bombastico", 1680, 640);
            Carta minipekka = new Carta("Mini PEKKA", 1361, 720);
            Carta gigante = new Carta("Gigante", 4091, 254);
            Carta bandida = new Carta("Bandida", 907, 193);
            Carta esbirros = new Carta("Esbirros", 230, 102);
            Carta babydragon = new Carta("Bebe dragon", 1152, 160);
            Carta magoelectrico = new Carta("Mago Electrico", 713, 225);
            Carta rayo = new Carta("Rayo", 0, 1056);

            
            //Agregando las cartas a los mazos
            Carta[] guerra = { megacaballero, globo, espejo, minipekka, magohielo, guardias, pandilla, lanzafuegos };
            Carta[] classicos = { gigante, esqueletos, tronco, bandida, esbirros, babydragon, magoelectrico, rayo };

            //Creando las 4 instancias de la clase Deck con el nombre que creamos en el excel
            Deck guerraclan = new Deck("GuerraClan", guerra);
            Deck classics = new Deck("Classics",classicos);
            //creacion de variables que almacenan el daño y los puntos de vida del mazo guerraclan
            int suma = guerraclan.GetDañoTotal(guerra);
            int vida = guerraclan.GetPuntosDeVida(guerra);
            //Propiedades del mazo guerraclan
            lblDañoGuerra.Text = Convert.ToString(suma);
            lblVidaGuerra.Text = Convert.ToString(vida);
            lblAtaque1.Text = "El ataque de" + Environment.NewLine+
                "este mazo es" + Environment.NewLine+
                "muy poderoso ya que" + Environment.NewLine+
                "cuenta con cartas fuertes" + Environment.NewLine+
                "aunque un poco costosas" ;
            lblBalance.Text = "El balance de este" + Environment.NewLine +
                "mazo" + 
                "es medio debido a" + Environment.NewLine+
                "que sus cartas son" + Environment.NewLine+
                "costosas, aunque si tiene" + Environment.NewLine+
                "ataque y una buena" +Environment.NewLine+
                "defensa";
            //Se muestra el nombre de cada carta con su imagen del mazo guerraclan
            lblMega.Text = guerraclan.Cartas[0].Nombre;
            lblGlobo.Text = guerraclan.Cartas[1].Nombre;
            lblEspejo.Text = guerraclan.Cartas[2].Nombre;
            lblMini.Text = guerraclan.Cartas[3].Nombre;
            lblMagohielo.Text = guerraclan.Cartas[4].Nombre;
            lblGuardias.Text = guerraclan.Cartas[5].Nombre;
            lblPandilla.Text = guerraclan.Cartas[6].Nombre;
            lblLanzafuego.Text = guerraclan.Cartas[7].Nombre;
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            pictureBox6.Visible = true;
            pictureBox7.Visible = true;
            pictureBox8.Visible = true;
            //Se muestra el nombre de cada carta con su imagen del mazo classics
            lblGigante.Text = classics.Cartas[0].Nombre;
            lblEsque.Text = classics.Cartas[1].Nombre;
            lblTron.Text = classics.Cartas[2].Nombre;
            lblBandida.Text = classics.Cartas[3].Nombre;
            lblEsbirros.Text = classics.Cartas[4].Nombre;
            lblBaby.Text = classics.Cartas[5].Nombre;
            lblMago.Text = classics.Cartas[6].Nombre;
            lblRayo.Text = classics.Cartas[7].Nombre;
            pictureBox9.Visible = true;
            pictureBox10.Visible = true;
            pictureBox11.Visible = true;
            pictureBox12.Visible = true;
            pictureBox13.Visible = true;
            pictureBox14.Visible = true;
            pictureBox15.Visible = true;
            pictureBox16.Visible = true;
            //creacion de variables que almacenan el daño y los puntos de vida del mazo classics
            int sumaclassics = classics.GetDañoTotal(classicos);
            int vidaClassics = classics.GetPuntosDeVida(classicos);
            string defensaClassics = "El ataque de este" + Environment.NewLine +
                "mazo es decente" + Environment.NewLine +
                "aunque podria ser mejor" + Environment.NewLine +
                "y sobretodo mas eficiente";
            string balanceClassics = "El balance de este" + Environment.NewLine +
                "mazo" +
                "es excelente" + Environment.NewLine +
                "debido a que tiene" + Environment.NewLine +
                "cartas de coste medio" + Environment.NewLine +
                "y se puede defender" + Environment.NewLine +
                "bastante bien";
            //Propiedades del mazo classics
            lblDañoSube.Text = Convert.ToString(sumaclassics);
            lblVidaSube.Text = Convert.ToString(vidaClassics);
            lblAtaque2.Text = defensaClassics;
            lblBalanceSube.Text = balanceClassics;
            


            
            
            
        }
        
        private void btnPvP_Click(object sender, EventArgs e)
        {
            PvP pvp = new PvP();
            pvp.Show();
        }
    }
}
