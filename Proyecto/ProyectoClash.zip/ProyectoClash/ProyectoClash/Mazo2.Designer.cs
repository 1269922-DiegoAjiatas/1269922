﻿namespace ProyectoClash
{
    partial class Mazo2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblBalanceElite = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.lblGigante1 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.lblVerdugo = new System.Windows.Forms.Label();
            this.lblCaballero = new System.Windows.Forms.Label();
            this.lblEspFuego = new System.Windows.Forms.Label();
            this.lblDraElectrico = new System.Windows.Forms.Label();
            this.lblDraInfernal = new System.Windows.Forms.Label();
            this.lblBarbaros = new System.Windows.Forms.Label();
            this.lblDescarga = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.label61 = new System.Windows.Forms.Label();
            this.lblAtaqueElite = new System.Windows.Forms.Label();
            this.lblVidaElite = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lblDañoElite = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.lblBalanceLog = new System.Windows.Forms.Label();
            this.lblAtaqueLog = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.lblEspHielo = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.lblTroncus = new System.Windows.Forms.Label();
            this.lblPrincesa = new System.Windows.Forms.Label();
            this.lblBarril = new System.Windows.Forms.Label();
            this.lblPandilla = new System.Windows.Forms.Label();
            this.lblCaballero2 = new System.Windows.Forms.Label();
            this.lblCohete = new System.Windows.Forms.Label();
            this.lblInfernal = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label90 = new System.Windows.Forms.Label();
            this.lblVidaLog = new System.Windows.Forms.Label();
            this.lblDañoLog = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.SteelBlue;
            this.groupBox2.Controls.Add(this.lblBalanceElite);
            this.groupBox2.Controls.Add(this.tableLayoutPanel3);
            this.groupBox2.Controls.Add(this.label61);
            this.groupBox2.Controls.Add(this.lblAtaqueElite);
            this.groupBox2.Controls.Add(this.lblVidaElite);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.lblDañoElite);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.label64);
            this.groupBox2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(438, 608);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Elite GDB";
            // 
            // lblBalanceElite
            // 
            this.lblBalanceElite.AutoSize = true;
            this.lblBalanceElite.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalanceElite.Location = new System.Drawing.Point(255, 372);
            this.lblBalanceElite.Name = "lblBalanceElite";
            this.lblBalanceElite.Size = new System.Drawing.Size(16, 18);
            this.lblBalanceElite.TabIndex = 26;
            this.lblBalanceElite.Text = "|";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label41, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label42, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label43, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label45, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.lblGigante1, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label48, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label49, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label50, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label51, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label52, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.label53, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.lblVerdugo, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.lblCaballero, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.lblEspFuego, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.lblDraElectrico, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.lblDraInfernal, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.lblBarbaros, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.lblDescarga, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox9, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox10, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox11, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox12, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox13, 2, 5);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox14, 2, 6);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox15, 2, 7);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox16, 2, 8);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(17, 58);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 9;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.Size = new System.Drawing.Size(233, 474);
            this.tableLayoutPanel3.TabIndex = 19;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(4, 1);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(29, 15);
            this.label40.TabIndex = 0;
            this.label40.Text = "No.";
            this.label40.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(40, 1);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(115, 15);
            this.label41.TabIndex = 1;
            this.label41.Text = "Nombre";
            this.label41.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(162, 1);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(67, 15);
            this.label42.TabIndex = 2;
            this.label42.Text = "Foto";
            this.label42.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(4, 17);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(29, 56);
            this.label43.TabIndex = 4;
            this.label43.Text = "1";
            this.label43.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(4, 74);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(29, 56);
            this.label45.TabIndex = 5;
            this.label45.Text = "2";
            this.label45.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblGigante1
            // 
            this.lblGigante1.AutoSize = true;
            this.lblGigante1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGigante1.Location = new System.Drawing.Point(40, 17);
            this.lblGigante1.Name = "lblGigante1";
            this.lblGigante1.Size = new System.Drawing.Size(115, 56);
            this.lblGigante1.TabIndex = 6;
            this.lblGigante1.Text = "|";
            this.lblGigante1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Location = new System.Drawing.Point(4, 131);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(29, 56);
            this.label48.TabIndex = 7;
            this.label48.Text = "3";
            this.label48.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Location = new System.Drawing.Point(4, 188);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(29, 56);
            this.label49.TabIndex = 8;
            this.label49.Text = "4";
            this.label49.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Location = new System.Drawing.Point(4, 245);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(29, 56);
            this.label50.TabIndex = 8;
            this.label50.Text = "5";
            this.label50.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(4, 302);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(29, 56);
            this.label51.TabIndex = 8;
            this.label51.Text = "6";
            this.label51.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(4, 359);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(29, 56);
            this.label52.TabIndex = 8;
            this.label52.Text = "7";
            this.label52.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.Location = new System.Drawing.Point(4, 416);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(29, 57);
            this.label53.TabIndex = 8;
            this.label53.Text = "8";
            this.label53.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblVerdugo
            // 
            this.lblVerdugo.AutoSize = true;
            this.lblVerdugo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVerdugo.Location = new System.Drawing.Point(40, 74);
            this.lblVerdugo.Name = "lblVerdugo";
            this.lblVerdugo.Size = new System.Drawing.Size(115, 56);
            this.lblVerdugo.TabIndex = 9;
            this.lblVerdugo.Text = "|";
            this.lblVerdugo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCaballero
            // 
            this.lblCaballero.AutoSize = true;
            this.lblCaballero.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCaballero.Location = new System.Drawing.Point(40, 131);
            this.lblCaballero.Name = "lblCaballero";
            this.lblCaballero.Size = new System.Drawing.Size(115, 56);
            this.lblCaballero.TabIndex = 9;
            this.lblCaballero.Text = "|";
            this.lblCaballero.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEspFuego
            // 
            this.lblEspFuego.AutoSize = true;
            this.lblEspFuego.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEspFuego.Location = new System.Drawing.Point(40, 188);
            this.lblEspFuego.Name = "lblEspFuego";
            this.lblEspFuego.Size = new System.Drawing.Size(115, 56);
            this.lblEspFuego.TabIndex = 9;
            this.lblEspFuego.Text = "|";
            this.lblEspFuego.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDraElectrico
            // 
            this.lblDraElectrico.AutoSize = true;
            this.lblDraElectrico.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDraElectrico.Location = new System.Drawing.Point(40, 245);
            this.lblDraElectrico.Name = "lblDraElectrico";
            this.lblDraElectrico.Size = new System.Drawing.Size(115, 56);
            this.lblDraElectrico.TabIndex = 9;
            this.lblDraElectrico.Text = "|";
            this.lblDraElectrico.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDraInfernal
            // 
            this.lblDraInfernal.AutoSize = true;
            this.lblDraInfernal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDraInfernal.Location = new System.Drawing.Point(40, 302);
            this.lblDraInfernal.Name = "lblDraInfernal";
            this.lblDraInfernal.Size = new System.Drawing.Size(115, 56);
            this.lblDraInfernal.TabIndex = 9;
            this.lblDraInfernal.Text = "|";
            this.lblDraInfernal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBarbaros
            // 
            this.lblBarbaros.AutoSize = true;
            this.lblBarbaros.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBarbaros.Location = new System.Drawing.Point(40, 359);
            this.lblBarbaros.Name = "lblBarbaros";
            this.lblBarbaros.Size = new System.Drawing.Size(115, 56);
            this.lblBarbaros.TabIndex = 9;
            this.lblBarbaros.Text = "|";
            this.lblBarbaros.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDescarga
            // 
            this.lblDescarga.AutoSize = true;
            this.lblDescarga.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDescarga.Location = new System.Drawing.Point(40, 416);
            this.lblDescarga.Name = "lblDescarga";
            this.lblDescarga.Size = new System.Drawing.Size(115, 57);
            this.lblDescarga.TabIndex = 9;
            this.lblDescarga.Text = "|";
            this.lblDescarga.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ProyectoClash.Properties.Resources.gigante;
            this.pictureBox9.Location = new System.Drawing.Point(162, 20);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(67, 50);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 10;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Visible = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ProyectoClash.Properties.Resources.verdugo;
            this.pictureBox10.Location = new System.Drawing.Point(162, 77);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(67, 50);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 10;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Visible = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::ProyectoClash.Properties.Resources.caballero;
            this.pictureBox11.Location = new System.Drawing.Point(162, 134);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(67, 50);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 10;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Visible = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::ProyectoClash.Properties.Resources.espfuego;
            this.pictureBox12.Location = new System.Drawing.Point(162, 191);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(67, 50);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 10;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Visible = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::ProyectoClash.Properties.Resources.dragonelectrico;
            this.pictureBox13.Location = new System.Drawing.Point(162, 248);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(67, 50);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 10;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Visible = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::ProyectoClash.Properties.Resources.dragoninfernal;
            this.pictureBox14.Location = new System.Drawing.Point(162, 305);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(67, 50);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 10;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Visible = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::ProyectoClash.Properties.Resources.barbaroselite;
            this.pictureBox15.Location = new System.Drawing.Point(162, 362);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(67, 50);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 10;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Visible = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::ProyectoClash.Properties.Resources.descarga;
            this.pictureBox16.Location = new System.Drawing.Point(162, 419);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(67, 50);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 10;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Visible = false;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(14, 37);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(115, 15);
            this.label61.TabIndex = 17;
            this.label61.Text = "Cartas a utilizar:";
            // 
            // lblAtaqueElite
            // 
            this.lblAtaqueElite.AutoSize = true;
            this.lblAtaqueElite.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAtaqueElite.Location = new System.Drawing.Point(253, 249);
            this.lblAtaqueElite.Name = "lblAtaqueElite";
            this.lblAtaqueElite.Size = new System.Drawing.Size(16, 18);
            this.lblAtaqueElite.TabIndex = 27;
            this.lblAtaqueElite.Text = "|";
            // 
            // lblVidaElite
            // 
            this.lblVidaElite.AutoSize = true;
            this.lblVidaElite.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVidaElite.Location = new System.Drawing.Point(252, 209);
            this.lblVidaElite.Name = "lblVidaElite";
            this.lblVidaElite.Size = new System.Drawing.Size(16, 18);
            this.lblVidaElite.TabIndex = 20;
            this.lblVidaElite.Text = "|";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label39.Location = new System.Drawing.Point(252, 158);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(45, 15);
            this.label39.TabIndex = 23;
            this.label39.Text = "Daño:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label30.Location = new System.Drawing.Point(252, 355);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(64, 15);
            this.label30.TabIndex = 24;
            this.label30.Text = "Balance:";
            // 
            // lblDañoElite
            // 
            this.lblDañoElite.AutoSize = true;
            this.lblDañoElite.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDañoElite.Location = new System.Drawing.Point(252, 174);
            this.lblDañoElite.Name = "lblDañoElite";
            this.lblDañoElite.Size = new System.Drawing.Size(16, 18);
            this.lblDañoElite.TabIndex = 21;
            this.lblDañoElite.Text = "|";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label38.Location = new System.Drawing.Point(248, 194);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(105, 15);
            this.label38.TabIndex = 22;
            this.label38.Text = "Puntos de vida:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label37.Location = new System.Drawing.Point(252, 232);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(57, 15);
            this.label37.TabIndex = 25;
            this.label37.Text = "Ataque:";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label64.Location = new System.Drawing.Point(249, 138);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(93, 15);
            this.label64.TabIndex = 18;
            this.label64.Text = "Propiedades:";
            // 
            // lblBalanceLog
            // 
            this.lblBalanceLog.AutoSize = true;
            this.lblBalanceLog.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalanceLog.Location = new System.Drawing.Point(244, 359);
            this.lblBalanceLog.Name = "lblBalanceLog";
            this.lblBalanceLog.Size = new System.Drawing.Size(16, 18);
            this.lblBalanceLog.TabIndex = 26;
            this.lblBalanceLog.Text = "|";
            // 
            // lblAtaqueLog
            // 
            this.lblAtaqueLog.AutoSize = true;
            this.lblAtaqueLog.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAtaqueLog.Location = new System.Drawing.Point(242, 228);
            this.lblAtaqueLog.Name = "lblAtaqueLog";
            this.lblAtaqueLog.Size = new System.Drawing.Size(16, 18);
            this.lblAtaqueLog.TabIndex = 27;
            this.lblAtaqueLog.Text = "|";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label67.Location = new System.Drawing.Point(241, 342);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(64, 15);
            this.label67.TabIndex = 24;
            this.label67.Text = "Balance:";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label68.Location = new System.Drawing.Point(241, 211);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(57, 15);
            this.label68.TabIndex = 25;
            this.label68.Text = "Ataque:";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label69.Location = new System.Drawing.Point(237, 173);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(105, 15);
            this.label69.TabIndex = 22;
            this.label69.Text = "Puntos de vida:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label70.Location = new System.Drawing.Point(241, 137);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(45, 15);
            this.label70.TabIndex = 23;
            this.label70.Text = "Daño:";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.Controls.Add(this.label71, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label72, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label73, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label74, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label75, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.lblEspHielo, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.label77, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label78, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label79, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.label80, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.label81, 0, 7);
            this.tableLayoutPanel4.Controls.Add(this.label82, 0, 8);
            this.tableLayoutPanel4.Controls.Add(this.lblTroncus, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.lblPrincesa, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.lblBarril, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.lblPandilla, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.lblCaballero2, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.lblCohete, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.lblInfernal, 1, 8);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox1, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox2, 2, 2);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox3, 2, 3);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox4, 2, 4);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox5, 2, 5);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox6, 2, 6);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox7, 2, 7);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox8, 2, 8);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(6, 37);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 9;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.Size = new System.Drawing.Size(233, 474);
            this.tableLayoutPanel4.TabIndex = 19;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label71.Location = new System.Drawing.Point(4, 1);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(29, 15);
            this.label71.TabIndex = 0;
            this.label71.Text = "No.";
            this.label71.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Location = new System.Drawing.Point(40, 1);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(115, 15);
            this.label72.TabIndex = 1;
            this.label72.Text = "Nombre";
            this.label72.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label73.Location = new System.Drawing.Point(162, 1);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(67, 15);
            this.label73.TabIndex = 2;
            this.label73.Text = "Foto";
            this.label73.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label74.Location = new System.Drawing.Point(4, 17);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(29, 56);
            this.label74.TabIndex = 4;
            this.label74.Text = "1";
            this.label74.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label75.Location = new System.Drawing.Point(4, 74);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(29, 56);
            this.label75.TabIndex = 5;
            this.label75.Text = "2";
            this.label75.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblEspHielo
            // 
            this.lblEspHielo.AutoSize = true;
            this.lblEspHielo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEspHielo.Location = new System.Drawing.Point(40, 17);
            this.lblEspHielo.Name = "lblEspHielo";
            this.lblEspHielo.Size = new System.Drawing.Size(115, 56);
            this.lblEspHielo.TabIndex = 6;
            this.lblEspHielo.Text = "|";
            this.lblEspHielo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label77.Location = new System.Drawing.Point(4, 131);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(29, 56);
            this.label77.TabIndex = 7;
            this.label77.Text = "3";
            this.label77.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(4, 188);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(29, 56);
            this.label78.TabIndex = 8;
            this.label78.Text = "4";
            this.label78.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(4, 245);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(29, 56);
            this.label79.TabIndex = 8;
            this.label79.Text = "5";
            this.label79.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label80.Location = new System.Drawing.Point(4, 302);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(29, 56);
            this.label80.TabIndex = 8;
            this.label80.Text = "6";
            this.label80.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label81.Location = new System.Drawing.Point(4, 359);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(29, 56);
            this.label81.TabIndex = 8;
            this.label81.Text = "7";
            this.label81.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label82.Location = new System.Drawing.Point(4, 416);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(29, 57);
            this.label82.TabIndex = 8;
            this.label82.Text = "8";
            this.label82.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTroncus
            // 
            this.lblTroncus.AutoSize = true;
            this.lblTroncus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTroncus.Location = new System.Drawing.Point(40, 74);
            this.lblTroncus.Name = "lblTroncus";
            this.lblTroncus.Size = new System.Drawing.Size(115, 56);
            this.lblTroncus.TabIndex = 9;
            this.lblTroncus.Text = "|";
            this.lblTroncus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPrincesa
            // 
            this.lblPrincesa.AutoSize = true;
            this.lblPrincesa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPrincesa.Location = new System.Drawing.Point(40, 131);
            this.lblPrincesa.Name = "lblPrincesa";
            this.lblPrincesa.Size = new System.Drawing.Size(115, 56);
            this.lblPrincesa.TabIndex = 9;
            this.lblPrincesa.Text = "|";
            this.lblPrincesa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBarril
            // 
            this.lblBarril.AutoSize = true;
            this.lblBarril.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBarril.Location = new System.Drawing.Point(40, 188);
            this.lblBarril.Name = "lblBarril";
            this.lblBarril.Size = new System.Drawing.Size(115, 56);
            this.lblBarril.TabIndex = 9;
            this.lblBarril.Text = "|";
            this.lblBarril.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPandilla
            // 
            this.lblPandilla.AutoSize = true;
            this.lblPandilla.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPandilla.Location = new System.Drawing.Point(40, 245);
            this.lblPandilla.Name = "lblPandilla";
            this.lblPandilla.Size = new System.Drawing.Size(115, 56);
            this.lblPandilla.TabIndex = 9;
            this.lblPandilla.Text = "|";
            this.lblPandilla.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCaballero2
            // 
            this.lblCaballero2.AutoSize = true;
            this.lblCaballero2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCaballero2.Location = new System.Drawing.Point(40, 302);
            this.lblCaballero2.Name = "lblCaballero2";
            this.lblCaballero2.Size = new System.Drawing.Size(115, 56);
            this.lblCaballero2.TabIndex = 9;
            this.lblCaballero2.Text = "|";
            this.lblCaballero2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCohete
            // 
            this.lblCohete.AutoSize = true;
            this.lblCohete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCohete.Location = new System.Drawing.Point(40, 359);
            this.lblCohete.Name = "lblCohete";
            this.lblCohete.Size = new System.Drawing.Size(115, 56);
            this.lblCohete.TabIndex = 9;
            this.lblCohete.Text = "|";
            this.lblCohete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblInfernal
            // 
            this.lblInfernal.AutoSize = true;
            this.lblInfernal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInfernal.Location = new System.Drawing.Point(40, 416);
            this.lblInfernal.Name = "lblInfernal";
            this.lblInfernal.Size = new System.Drawing.Size(115, 57);
            this.lblInfernal.TabIndex = 9;
            this.lblInfernal.Text = "|";
            this.lblInfernal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProyectoClash.Properties.Resources.espirituhielo;
            this.pictureBox1.Location = new System.Drawing.Point(162, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(67, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProyectoClash.Properties.Resources.tronco1;
            this.pictureBox2.Location = new System.Drawing.Point(162, 77);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(67, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ProyectoClash.Properties.Resources.princesa;
            this.pictureBox3.Location = new System.Drawing.Point(162, 134);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(67, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ProyectoClash.Properties.Resources.barril;
            this.pictureBox4.Location = new System.Drawing.Point(162, 191);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(67, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::ProyectoClash.Properties.Resources.pandila;
            this.pictureBox5.Location = new System.Drawing.Point(162, 248);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(67, 50);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 10;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ProyectoClash.Properties.Resources.caballero;
            this.pictureBox6.Location = new System.Drawing.Point(162, 305);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(67, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 10;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Visible = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ProyectoClash.Properties.Resources.cohete;
            this.pictureBox7.Location = new System.Drawing.Point(162, 362);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(67, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 10;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Visible = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ProyectoClash.Properties.Resources.infernal;
            this.pictureBox8.Location = new System.Drawing.Point(162, 419);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(67, 50);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 10;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Visible = false;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(10, 20);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(115, 15);
            this.label90.TabIndex = 17;
            this.label90.Text = "Cartas a utilizar:";
            // 
            // lblVidaLog
            // 
            this.lblVidaLog.AutoSize = true;
            this.lblVidaLog.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVidaLog.Location = new System.Drawing.Point(241, 188);
            this.lblVidaLog.Name = "lblVidaLog";
            this.lblVidaLog.Size = new System.Drawing.Size(16, 18);
            this.lblVidaLog.TabIndex = 20;
            this.lblVidaLog.Text = "|";
            // 
            // lblDañoLog
            // 
            this.lblDañoLog.AutoSize = true;
            this.lblDañoLog.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDañoLog.Location = new System.Drawing.Point(241, 153);
            this.lblDañoLog.Name = "lblDañoLog";
            this.lblDañoLog.Size = new System.Drawing.Size(16, 18);
            this.lblDañoLog.TabIndex = 21;
            this.lblDañoLog.Text = "|";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label93.Location = new System.Drawing.Point(238, 117);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(93, 15);
            this.label93.TabIndex = 18;
            this.label93.Text = "Propiedades:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.SteelBlue;
            this.groupBox1.Controls.Add(this.lblBalanceLog);
            this.groupBox1.Controls.Add(this.tableLayoutPanel4);
            this.groupBox1.Controls.Add(this.lblAtaqueLog);
            this.groupBox1.Controls.Add(this.label93);
            this.groupBox1.Controls.Add(this.label67);
            this.groupBox1.Controls.Add(this.lblDañoLog);
            this.groupBox1.Controls.Add(this.label68);
            this.groupBox1.Controls.Add(this.lblVidaLog);
            this.groupBox1.Controls.Add(this.label69);
            this.groupBox1.Controls.Add(this.label90);
            this.groupBox1.Controls.Add(this.label70);
            this.groupBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(617, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(440, 608);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Log Bait";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(468, 304);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 36);
            this.button1.TabIndex = 7;
            this.button1.Text = "Ver Mazos";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Mazo2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1068, 648);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Mazo2";
            this.Text = "Mazo2";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.Label lblBalanceElite;
        public System.Windows.Forms.Label lblAtaqueElite;
        public System.Windows.Forms.Label label30;
        public System.Windows.Forms.Label label37;
        public System.Windows.Forms.Label label38;
        public System.Windows.Forms.Label label39;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label lblGigante1;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label lblCaballero;
        private System.Windows.Forms.Label lblEspFuego;
        private System.Windows.Forms.Label lblDraElectrico;
        private System.Windows.Forms.Label lblDraInfernal;
        private System.Windows.Forms.Label lblBarbaros;
        private System.Windows.Forms.Label lblDescarga;
        private System.Windows.Forms.Label label61;
        public System.Windows.Forms.Label lblVidaElite;
        public System.Windows.Forms.Label lblDañoElite;
        public System.Windows.Forms.Label label64;
        public System.Windows.Forms.Label lblBalanceLog;
        public System.Windows.Forms.Label lblAtaqueLog;
        public System.Windows.Forms.Label label67;
        public System.Windows.Forms.Label label68;
        public System.Windows.Forms.Label label69;
        public System.Windows.Forms.Label label70;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label lblEspHielo;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label lblTroncus;
        private System.Windows.Forms.Label lblPrincesa;
        private System.Windows.Forms.Label lblBarril;
        private System.Windows.Forms.Label lblPandilla;
        private System.Windows.Forms.Label lblCaballero2;
        private System.Windows.Forms.Label lblCohete;
        private System.Windows.Forms.Label lblInfernal;
        private System.Windows.Forms.Label label90;
        public System.Windows.Forms.Label lblVidaLog;
        public System.Windows.Forms.Label lblDañoLog;
        public System.Windows.Forms.Label label93;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblVerdugo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
    }
}