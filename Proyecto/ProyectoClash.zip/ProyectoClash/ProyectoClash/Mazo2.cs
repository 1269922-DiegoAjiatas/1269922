﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoClash
{
    public partial class Mazo2 : Form
    {
        public Mazo2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Creando las cartas que se utilizaran
            Carta megacaballero = new Carta("Megacaballero", 3993, 268);
            Carta tronco = new Carta("Tronco", 0, 290);
            Carta cohete = new Carta("Cohete", 0, 1484);
            Carta espirituHielo = new Carta("Espiritu de Hielo", 230, 110);
            Carta magohielo = new Carta("Mago de Hielo", 688, 90);
            Carta guardias = new Carta("Guardias", 81, 121);
            Carta pandilla = new Carta("Pandilla de duendes", 133, 81);
            Carta lanzafuegos = new Carta("Lanzafuegos", 304, 320);
            Carta esqueletos = new Carta("Esqueletos", 81, 81);
            Carta arqueromagico = new Carta("Arquero Magico", 532, 134);
            Carta princesa = new Carta("Princesa", 261, 169);
            Carta duendesclanza = new Carta("Duendes con lanza", 133, 81);
            Carta tornado = new Carta("Tornado", 0, 169);
            Carta infernal = new Carta("Torre Infernal", 1749, 42);
            Carta dragoninfernal = new Carta("Dragon Infernal", 1294, 36);
            Carta murcielagos = new Carta("Murcielagos", 81, 81);
            Carta sabueso = new Carta("Sabueso de lava", 3811, 54);
            Carta barbaros = new Carta("Barbaros de Elite", 1391, 384);
            Carta barril = new Carta("Barril de duendes", 133, 81);
            Carta minipekka = new Carta("Mini PEKKA", 1361, 720);
            Carta verdugo = new Carta("Verdugo", 1280, 339);
            Carta descarga = new Carta("Descarga", 0, 192);
            Carta dragonelectrico = new Carta("Dragon Electrico", 950, 192);
            Carta gigante = new Carta("Gigante", 4091, 254);
            Carta bandida = new Carta("Bandida", 907, 193);
            Carta espiritufuego = new Carta("Espiritu de Fuego", 230, 207);
            Carta babydragon = new Carta("Bebe dragon", 1152, 160);
            Carta magoelectrico = new Carta("Mago Electrico", 713, 225);
            Carta caballero = new Carta("Caballero", 1753, 202);


            //Agregando las cartas a los mazos
            Carta[] elite = { gigante, verdugo, caballero, espiritufuego, dragonelectrico, dragoninfernal, barbaros, descarga };
            Carta[] log = { espirituHielo, tronco, princesa, barril, pandilla, caballero, cohete, infernal };

            //Creando las 4 instancias de la clase Deck con el nombre que creamos en el excel
            Deck elitegdb = new Deck("EliteGDB", elite);
            Deck logbait = new Deck("Log Bait", log);
            //creacion de variables que almacenan el daño y los puntos de vida del mazo elitegdb
            int suma = elitegdb.GetDañoTotal(elite);
            int vida = elitegdb.GetPuntosDeVida(elite);
            //Propiedades del mazo elitegdb
            lblDañoElite.Text = Convert.ToString(suma);
            lblVidaElite.Text = Convert.ToString(vida);
            lblAtaqueElite.Text = "El ataque de" + Environment.NewLine +
                "este mazo puede ser" + Environment.NewLine +
                "poderoso si se arma un" + Environment.NewLine +
                "buen combo con sus cartas" + Environment.NewLine +
                "y ayuda que no sean tan" + Environment.NewLine+
                "costosas";
            lblBalanceElite.Text = "El balance de este" + Environment.NewLine +
                "mazo" +
                "es medio debido a" + Environment.NewLine +
                "que sus cartas son" + Environment.NewLine +
                "costosas, aunque si tiene" + Environment.NewLine +
                "ataque y una buena" + Environment.NewLine +
                "defensa";
            //Se muestra el nombre de cada carta con su imagen del mazo elitegdb
            lblGigante1.Text = elitegdb.Cartas[0].Nombre;
            lblVerdugo.Text = elitegdb.Cartas[1].Nombre;
            lblCaballero.Text = elitegdb.Cartas[2].Nombre;
            lblEspFuego.Text = elitegdb.Cartas[3].Nombre;
            lblDraElectrico.Text = elitegdb.Cartas[4].Nombre;
            lblDraInfernal.Text = elitegdb.Cartas[5].Nombre;
            lblBarbaros.Text = elitegdb.Cartas[6].Nombre;
            lblDescarga.Text = elitegdb.Cartas[7].Nombre;
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            pictureBox6.Visible = true;
            pictureBox7.Visible = true;
            pictureBox8.Visible = true;
            //Se muestra el nombre de cada carta con su imagen del mazo classics
            lblEspHielo.Text = logbait.Cartas[0].Nombre;
            lblTroncus.Text = logbait.Cartas[1].Nombre;
            lblPrincesa.Text = logbait.Cartas[2].Nombre;
            lblBarril.Text = logbait.Cartas[3].Nombre;
            lblPandilla.Text = logbait.Cartas[4].Nombre;
            lblCaballero2.Text = logbait.Cartas[5].Nombre;
            lblCohete.Text = logbait.Cartas[6].Nombre;
            lblInfernal.Text = logbait.Cartas[7].Nombre;
            pictureBox9.Visible = true;
            pictureBox10.Visible = true;
            pictureBox11.Visible = true;
            pictureBox12.Visible = true;
            pictureBox13.Visible = true;
            pictureBox14.Visible = true;
            pictureBox15.Visible = true;
            pictureBox16.Visible = true;
            //creacion de variables que almacenan el daño y los puntos de vida del mazo classics
            int sumaLog = logbait.GetDañoTotal(log);
            int vidaLog = logbait.GetPuntosDeVida(log);
            string ataqueLog = "El ataque de este" + Environment.NewLine +
                "mazo es rapido por lo" + Environment.NewLine +
                "que se debe jugar con" + Environment.NewLine+
                "estrategia, tambien es" + Environment.NewLine +
                "muy eficiente";
            string balanceLog = "El balance de este" + Environment.NewLine +
                "mazo" +
                "es excelente" + Environment.NewLine +
                "debido a que tiene" + Environment.NewLine +
                "cartas de coste bajo" + Environment.NewLine +
                "y se puede defender y" + Environment.NewLine +
                "atacar bastante bien";
            //Propiedades del mazo classics
            lblDañoLog.Text = Convert.ToString(sumaLog);
            lblVidaLog.Text = Convert.ToString(vidaLog);
            lblAtaqueLog.Text = ataqueLog;
            lblBalanceLog.Text = balanceLog;
        }
    }
}
