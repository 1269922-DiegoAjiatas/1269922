﻿namespace ProyectoClash
{
    partial class Mazos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblVidaGuerra = new System.Windows.Forms.Label();
            this.lblDañoGuerra = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblMega = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblGlobo = new System.Windows.Forms.Label();
            this.lblEspejo = new System.Windows.Forms.Label();
            this.lblMini = new System.Windows.Forms.Label();
            this.lblMagohielo = new System.Windows.Forms.Label();
            this.lblGuardias = new System.Windows.Forms.Label();
            this.lblPandilla = new System.Windows.Forms.Label();
            this.lblLanzafuego = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblAtaque1 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblBalanceSube = new System.Windows.Forms.Label();
            this.lblAtaque2 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lblGigante = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.lblEsque = new System.Windows.Forms.Label();
            this.lblTron = new System.Windows.Forms.Label();
            this.lblBandida = new System.Windows.Forms.Label();
            this.lblEsbirros = new System.Windows.Forms.Label();
            this.lblBaby = new System.Windows.Forms.Label();
            this.lblMago = new System.Windows.Forms.Label();
            this.lblRayo = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.label44 = new System.Windows.Forms.Label();
            this.lblVidaSube = new System.Windows.Forms.Label();
            this.lblDañoSube = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(253, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Propiedades:";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(474, 382);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 43);
            this.button1.TabIndex = 1;
            this.button1.Text = "Ver Mazos";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.SlateBlue;
            this.groupBox1.Controls.Add(this.lblVidaGuerra);
            this.groupBox1.Controls.Add(this.lblDañoGuerra);
            this.groupBox1.Controls.Add(this.tableLayoutPanel1);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lblBalance);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lblAtaque1);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(4, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(449, 608);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "GuerraClan";
            // 
            // lblVidaGuerra
            // 
            this.lblVidaGuerra.AutoSize = true;
            this.lblVidaGuerra.Location = new System.Drawing.Point(258, 207);
            this.lblVidaGuerra.Name = "lblVidaGuerra";
            this.lblVidaGuerra.Size = new System.Drawing.Size(11, 15);
            this.lblVidaGuerra.TabIndex = 7;
            this.lblVidaGuerra.Text = "|";
            // 
            // lblDañoGuerra
            // 
            this.lblDañoGuerra.AutoSize = true;
            this.lblDañoGuerra.Location = new System.Drawing.Point(258, 171);
            this.lblDañoGuerra.Name = "lblDañoGuerra";
            this.lblDañoGuerra.Size = new System.Drawing.Size(11, 15);
            this.lblDañoGuerra.TabIndex = 6;
            this.lblDañoGuerra.Text = "|";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblMega, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblGlobo, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblEspejo, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblMini, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblMagohielo, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblGuardias, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblPandilla, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblLanzafuego, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox3, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox4, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox5, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox6, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox7, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox8, 2, 8);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(21, 54);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 9;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(233, 474);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(4, 1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "No.";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(40, 1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 15);
            this.label5.TabIndex = 1;
            this.label5.Text = "Nombre";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(165, 1);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 15);
            this.label6.TabIndex = 2;
            this.label6.Text = "Foto";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(4, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 56);
            this.label7.TabIndex = 4;
            this.label7.Text = "1";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(4, 74);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 56);
            this.label8.TabIndex = 5;
            this.label8.Text = "2";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMega
            // 
            this.lblMega.AutoSize = true;
            this.lblMega.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMega.Location = new System.Drawing.Point(40, 17);
            this.lblMega.Name = "lblMega";
            this.lblMega.Size = new System.Drawing.Size(118, 56);
            this.lblMega.TabIndex = 6;
            this.lblMega.Text = "|";
            this.lblMega.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(4, 131);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 56);
            this.label10.TabIndex = 7;
            this.label10.Text = "3";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(4, 188);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 56);
            this.label11.TabIndex = 8;
            this.label11.Text = "4";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Location = new System.Drawing.Point(4, 245);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 56);
            this.label12.TabIndex = 8;
            this.label12.Text = "5";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Location = new System.Drawing.Point(4, 302);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 56);
            this.label13.TabIndex = 8;
            this.label13.Text = "6";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(4, 359);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 56);
            this.label14.TabIndex = 8;
            this.label14.Text = "7";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(4, 416);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 57);
            this.label15.TabIndex = 8;
            this.label15.Text = "8";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblGlobo
            // 
            this.lblGlobo.AutoSize = true;
            this.lblGlobo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGlobo.Location = new System.Drawing.Point(40, 74);
            this.lblGlobo.Name = "lblGlobo";
            this.lblGlobo.Size = new System.Drawing.Size(118, 56);
            this.lblGlobo.TabIndex = 9;
            this.lblGlobo.Text = "|";
            this.lblGlobo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEspejo
            // 
            this.lblEspejo.AutoSize = true;
            this.lblEspejo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEspejo.Location = new System.Drawing.Point(40, 131);
            this.lblEspejo.Name = "lblEspejo";
            this.lblEspejo.Size = new System.Drawing.Size(118, 56);
            this.lblEspejo.TabIndex = 9;
            this.lblEspejo.Text = "|";
            this.lblEspejo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMini
            // 
            this.lblMini.AutoSize = true;
            this.lblMini.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMini.Location = new System.Drawing.Point(40, 188);
            this.lblMini.Name = "lblMini";
            this.lblMini.Size = new System.Drawing.Size(118, 56);
            this.lblMini.TabIndex = 9;
            this.lblMini.Text = "|";
            this.lblMini.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMagohielo
            // 
            this.lblMagohielo.AutoSize = true;
            this.lblMagohielo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMagohielo.Location = new System.Drawing.Point(40, 245);
            this.lblMagohielo.Name = "lblMagohielo";
            this.lblMagohielo.Size = new System.Drawing.Size(118, 56);
            this.lblMagohielo.TabIndex = 9;
            this.lblMagohielo.Text = "|";
            this.lblMagohielo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGuardias
            // 
            this.lblGuardias.AutoSize = true;
            this.lblGuardias.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGuardias.Location = new System.Drawing.Point(40, 302);
            this.lblGuardias.Name = "lblGuardias";
            this.lblGuardias.Size = new System.Drawing.Size(118, 56);
            this.lblGuardias.TabIndex = 9;
            this.lblGuardias.Text = "|";
            this.lblGuardias.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPandilla
            // 
            this.lblPandilla.AutoSize = true;
            this.lblPandilla.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPandilla.Location = new System.Drawing.Point(40, 359);
            this.lblPandilla.Name = "lblPandilla";
            this.lblPandilla.Size = new System.Drawing.Size(118, 56);
            this.lblPandilla.TabIndex = 9;
            this.lblPandilla.Text = "|";
            this.lblPandilla.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLanzafuego
            // 
            this.lblLanzafuego.AutoSize = true;
            this.lblLanzafuego.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLanzafuego.Location = new System.Drawing.Point(40, 416);
            this.lblLanzafuego.Name = "lblLanzafuego";
            this.lblLanzafuego.Size = new System.Drawing.Size(118, 57);
            this.lblLanzafuego.TabIndex = 9;
            this.lblLanzafuego.Text = "|";
            this.lblLanzafuego.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProyectoClash.Properties.Resources.megacaballero;
            this.pictureBox1.Location = new System.Drawing.Point(165, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProyectoClash.Properties.Resources.globo;
            this.pictureBox2.Location = new System.Drawing.Point(165, 77);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(64, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ProyectoClash.Properties.Resources.espejo;
            this.pictureBox3.Location = new System.Drawing.Point(165, 134);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(64, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ProyectoClash.Properties.Resources.minipeka;
            this.pictureBox4.Location = new System.Drawing.Point(165, 191);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(64, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::ProyectoClash.Properties.Resources.magohielo;
            this.pictureBox5.Location = new System.Drawing.Point(165, 248);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(64, 50);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 10;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ProyectoClash.Properties.Resources.guardias;
            this.pictureBox6.Location = new System.Drawing.Point(165, 305);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(64, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 10;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Visible = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ProyectoClash.Properties.Resources.pandila;
            this.pictureBox7.Location = new System.Drawing.Point(165, 362);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(64, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 10;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Visible = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ProyectoClash.Properties.Resources.lanzafuegos;
            this.pictureBox8.Location = new System.Drawing.Point(165, 419);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(64, 50);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 10;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(256, 154);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 15);
            this.label9.TabIndex = 3;
            this.label9.Text = "Daño:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label16.Location = new System.Drawing.Point(252, 191);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(105, 15);
            this.label16.TabIndex = 3;
            this.label16.Text = "Puntos de vida:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "Cartas a utilizar:";
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalance.Location = new System.Drawing.Point(259, 352);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(16, 18);
            this.lblBalance.TabIndex = 5;
            this.lblBalance.Text = "|";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label17.Location = new System.Drawing.Point(256, 230);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(57, 15);
            this.label17.TabIndex = 4;
            this.label17.Text = "Ataque:";
            // 
            // lblAtaque1
            // 
            this.lblAtaque1.AutoSize = true;
            this.lblAtaque1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAtaque1.Location = new System.Drawing.Point(257, 247);
            this.lblAtaque1.Name = "lblAtaque1";
            this.lblAtaque1.Size = new System.Drawing.Size(16, 18);
            this.lblAtaque1.TabIndex = 5;
            this.lblAtaque1.Text = "|";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label18.Location = new System.Drawing.Point(256, 335);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 15);
            this.label18.TabIndex = 4;
            this.label18.Text = "Balance:";
            // 
            // lblBalanceSube
            // 
            this.lblBalanceSube.AutoSize = true;
            this.lblBalanceSube.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalanceSube.Location = new System.Drawing.Point(271, 356);
            this.lblBalanceSube.Name = "lblBalanceSube";
            this.lblBalanceSube.Size = new System.Drawing.Size(16, 18);
            this.lblBalanceSube.TabIndex = 15;
            this.lblBalanceSube.Text = "|";
            // 
            // lblAtaque2
            // 
            this.lblAtaque2.AutoSize = true;
            this.lblAtaque2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAtaque2.Location = new System.Drawing.Point(269, 252);
            this.lblAtaque2.Name = "lblAtaque2";
            this.lblAtaque2.Size = new System.Drawing.Size(16, 18);
            this.lblAtaque2.TabIndex = 16;
            this.lblAtaque2.Text = "|";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label21.Location = new System.Drawing.Point(268, 339);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(64, 15);
            this.label21.TabIndex = 13;
            this.label21.Text = "Balance:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label22.Location = new System.Drawing.Point(268, 235);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 15);
            this.label22.TabIndex = 14;
            this.label22.Text = "Ataque:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label23.Location = new System.Drawing.Point(264, 196);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(105, 15);
            this.label23.TabIndex = 11;
            this.label23.Text = "Puntos de vida:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label24.Location = new System.Drawing.Point(268, 158);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(45, 15);
            this.label24.TabIndex = 12;
            this.label24.Text = "Daño:";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.label25, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label26, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label27, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label28, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label29, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblGigante, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label31, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label32, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label33, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label34, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label35, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.label36, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.lblEsque, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblTron, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.lblBandida, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.lblEsbirros, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.lblBaby, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.lblMago, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.lblRayo, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox9, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox10, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox11, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox12, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox13, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox14, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox15, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox16, 2, 8);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(18, 54);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(240, 473);
            this.tableLayoutPanel2.TabIndex = 8;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(4, 1);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 15);
            this.label25.TabIndex = 0;
            this.label25.Text = "No.";
            this.label25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Location = new System.Drawing.Point(40, 1);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(124, 15);
            this.label26.TabIndex = 1;
            this.label26.Text = "Nombre";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Location = new System.Drawing.Point(171, 1);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(65, 15);
            this.label27.TabIndex = 2;
            this.label27.Text = "Foto";
            this.label27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Location = new System.Drawing.Point(4, 17);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(29, 56);
            this.label28.TabIndex = 4;
            this.label28.Text = "1";
            this.label28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Location = new System.Drawing.Point(4, 74);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 56);
            this.label29.TabIndex = 5;
            this.label29.Text = "2";
            this.label29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblGigante
            // 
            this.lblGigante.AutoSize = true;
            this.lblGigante.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGigante.Location = new System.Drawing.Point(40, 17);
            this.lblGigante.Name = "lblGigante";
            this.lblGigante.Size = new System.Drawing.Size(124, 56);
            this.lblGigante.TabIndex = 6;
            this.lblGigante.Text = "|";
            this.lblGigante.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Location = new System.Drawing.Point(4, 131);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(29, 56);
            this.label31.TabIndex = 7;
            this.label31.Text = "3";
            this.label31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Location = new System.Drawing.Point(4, 188);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(29, 56);
            this.label32.TabIndex = 8;
            this.label32.Text = "4";
            this.label32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Location = new System.Drawing.Point(4, 245);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(29, 56);
            this.label33.TabIndex = 8;
            this.label33.Text = "5";
            this.label33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Location = new System.Drawing.Point(4, 302);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(29, 56);
            this.label34.TabIndex = 8;
            this.label34.Text = "6";
            this.label34.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(4, 359);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(29, 56);
            this.label35.TabIndex = 8;
            this.label35.Text = "7";
            this.label35.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(4, 416);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 56);
            this.label36.TabIndex = 8;
            this.label36.Text = "8";
            this.label36.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblEsque
            // 
            this.lblEsque.AutoSize = true;
            this.lblEsque.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEsque.Location = new System.Drawing.Point(40, 74);
            this.lblEsque.Name = "lblEsque";
            this.lblEsque.Size = new System.Drawing.Size(124, 56);
            this.lblEsque.TabIndex = 9;
            this.lblEsque.Text = "|";
            this.lblEsque.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTron
            // 
            this.lblTron.AutoSize = true;
            this.lblTron.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTron.Location = new System.Drawing.Point(40, 131);
            this.lblTron.Name = "lblTron";
            this.lblTron.Size = new System.Drawing.Size(124, 56);
            this.lblTron.TabIndex = 9;
            this.lblTron.Text = "|";
            this.lblTron.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBandida
            // 
            this.lblBandida.AutoSize = true;
            this.lblBandida.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBandida.Location = new System.Drawing.Point(40, 188);
            this.lblBandida.Name = "lblBandida";
            this.lblBandida.Size = new System.Drawing.Size(124, 56);
            this.lblBandida.TabIndex = 9;
            this.lblBandida.Text = "|";
            this.lblBandida.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEsbirros
            // 
            this.lblEsbirros.AutoSize = true;
            this.lblEsbirros.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEsbirros.Location = new System.Drawing.Point(40, 245);
            this.lblEsbirros.Name = "lblEsbirros";
            this.lblEsbirros.Size = new System.Drawing.Size(124, 56);
            this.lblEsbirros.TabIndex = 9;
            this.lblEsbirros.Text = "|";
            this.lblEsbirros.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBaby
            // 
            this.lblBaby.AutoSize = true;
            this.lblBaby.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBaby.Location = new System.Drawing.Point(40, 302);
            this.lblBaby.Name = "lblBaby";
            this.lblBaby.Size = new System.Drawing.Size(124, 56);
            this.lblBaby.TabIndex = 9;
            this.lblBaby.Text = "|";
            this.lblBaby.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMago
            // 
            this.lblMago.AutoSize = true;
            this.lblMago.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMago.Location = new System.Drawing.Point(40, 359);
            this.lblMago.Name = "lblMago";
            this.lblMago.Size = new System.Drawing.Size(124, 56);
            this.lblMago.TabIndex = 9;
            this.lblMago.Text = "|";
            this.lblMago.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRayo
            // 
            this.lblRayo.AutoSize = true;
            this.lblRayo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRayo.Location = new System.Drawing.Point(40, 416);
            this.lblRayo.Name = "lblRayo";
            this.lblRayo.Size = new System.Drawing.Size(124, 56);
            this.lblRayo.TabIndex = 9;
            this.lblRayo.Text = "|";
            this.lblRayo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ProyectoClash.Properties.Resources.gigante;
            this.pictureBox9.Location = new System.Drawing.Point(171, 20);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(65, 50);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 10;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Visible = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ProyectoClash.Properties.Resources.esqueletos1;
            this.pictureBox10.Location = new System.Drawing.Point(171, 77);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(65, 50);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 10;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Visible = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::ProyectoClash.Properties.Resources.tronco1;
            this.pictureBox11.Location = new System.Drawing.Point(171, 134);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(65, 50);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 10;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Visible = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::ProyectoClash.Properties.Resources.bandida;
            this.pictureBox12.Location = new System.Drawing.Point(171, 191);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(65, 50);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 10;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Visible = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::ProyectoClash.Properties.Resources.esbirros;
            this.pictureBox13.Location = new System.Drawing.Point(171, 248);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(65, 50);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 10;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Visible = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::ProyectoClash.Properties.Resources.baby;
            this.pictureBox14.Location = new System.Drawing.Point(171, 305);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(65, 50);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 10;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Visible = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::ProyectoClash.Properties.Resources.mago;
            this.pictureBox15.Location = new System.Drawing.Point(171, 362);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(65, 50);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 10;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Visible = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::ProyectoClash.Properties.Resources.rayo;
            this.pictureBox16.Location = new System.Drawing.Point(171, 419);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(65, 50);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 10;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Visible = false;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(15, 33);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(115, 15);
            this.label44.TabIndex = 6;
            this.label44.Text = "Cartas a utilizar:";
            // 
            // lblVidaSube
            // 
            this.lblVidaSube.AutoSize = true;
            this.lblVidaSube.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVidaSube.Location = new System.Drawing.Point(269, 212);
            this.lblVidaSube.Name = "lblVidaSube";
            this.lblVidaSube.Size = new System.Drawing.Size(16, 18);
            this.lblVidaSube.TabIndex = 9;
            this.lblVidaSube.Text = "|";
            // 
            // lblDañoSube
            // 
            this.lblDañoSube.AutoSize = true;
            this.lblDañoSube.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDañoSube.Location = new System.Drawing.Point(269, 173);
            this.lblDañoSube.Name = "lblDañoSube";
            this.lblDañoSube.Size = new System.Drawing.Size(16, 18);
            this.lblDañoSube.TabIndex = 10;
            this.lblDañoSube.Text = "|";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label47.Location = new System.Drawing.Point(265, 138);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(93, 15);
            this.label47.TabIndex = 7;
            this.label47.Text = "Propiedades:";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.SlateBlue;
            this.groupBox2.Controls.Add(this.lblBalanceSube);
            this.groupBox2.Controls.Add(this.tableLayoutPanel2);
            this.groupBox2.Controls.Add(this.lblAtaque2);
            this.groupBox2.Controls.Add(this.label47);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.lblDañoSube);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.lblVidaSube);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(603, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(431, 607);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Classics";
            // 
            // Mazos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ClientSize = new System.Drawing.Size(1120, 657);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Mazos";
            this.Text = "Mazos";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblMega;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblGlobo;
        private System.Windows.Forms.Label lblEspejo;
        private System.Windows.Forms.Label lblMini;
        private System.Windows.Forms.Label lblMagohielo;
        private System.Windows.Forms.Label lblGuardias;
        private System.Windows.Forms.Label lblPandilla;
        private System.Windows.Forms.Label lblLanzafuego;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblGigante;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label lblEsque;
        private System.Windows.Forms.Label lblTron;
        private System.Windows.Forms.Label lblBandida;
        private System.Windows.Forms.Label lblEsbirros;
        private System.Windows.Forms.Label lblBaby;
        private System.Windows.Forms.Label lblMago;
        private System.Windows.Forms.Label lblRayo;
        private System.Windows.Forms.Label label44;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label lblBalance;
        public System.Windows.Forms.Label lblAtaque1;
        public System.Windows.Forms.Label label18;
        public System.Windows.Forms.Label label17;
        public System.Windows.Forms.Label lblBalanceSube;
        public System.Windows.Forms.Label lblAtaque2;
        public System.Windows.Forms.Label label21;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.Label label23;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.Label lblVidaSube;
        public System.Windows.Forms.Label lblDañoSube;
        public System.Windows.Forms.Label label47;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblVidaGuerra;
        private System.Windows.Forms.Label lblDañoGuerra;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
    }
}